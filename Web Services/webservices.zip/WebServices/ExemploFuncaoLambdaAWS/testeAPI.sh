curl -v -X "PUT" -H "Content-Type: application/json" -d "{\"id\": \"abcdef234\", \"price\": 12345, \"name\": \"myitem\"}" https://b04kxrgw9j.execute-api.us-east-1.amazonaws.com/items
