const SequenceRoute = require('./sequenceRoute')
module.exports = (app) => {
    SequenceRoute(app)
}
