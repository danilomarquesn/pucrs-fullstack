echo ""
echo " Iniciando configurações: "
sh master.sh
sh node1.sh
sh node2.sh
sh node3.sh
echo ""
echo " Master e Nodes 1, 2, 3 iniciados e configurados"
