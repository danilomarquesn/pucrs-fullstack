terraform destroy -auto-approve
