# Amazon Linux AMI

> curl -L https://raw.githubusercontent.com/tonanuvem/config/master/aws-vm/config.sh | sh -
