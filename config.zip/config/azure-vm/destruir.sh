terraform destroy -auto-approve
az group delete --yes --resource-group fiapvm
