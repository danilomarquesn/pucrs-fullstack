Links:

<li> https://galaxy.ansible.com/

<li> https://docs.ansible.com/ansible/2.9/modules/modules_by_category.html

<li> https://docs.ansible.com/ansible/latest/user_guide/playbooks_conditionals.html#playbooks-conditionals

<li> https://docs.ansible.com/ansible/latest/user_guide/playbooks_loops.html#playbooks-loops

<li> https://github.com/MiteshSharma/InfraTerraformAnsible/tree/master/ansible

<li> https://dev.to/email2vimalraj/collect-failed-task-details-in-ansible-4hcf
