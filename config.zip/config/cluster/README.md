# Cria 3 maquinas virtuais (EC2) para os LABs relacionados a Alta Disponibilidade e Cluster:

As seguintes VMs serão criadas:

<li> Master 
<li> Node 1
<li> Node 2

Fontes:

> https://www.terraform.io/docs/providers/template/d/cloudinit_config.html <br>
> https://github.com/terraform-providers/terraform-provider-aws/issues/1148 <br>
> https://github.com/cyr-riv/terraform/tree/master/rancher-single-aws
