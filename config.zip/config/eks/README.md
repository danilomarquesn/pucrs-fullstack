Lab do EKS baseado nos seguintes documentos:

- https://docs.aws.amazon.com/eks/latest/userguide/getting-started-console.html

- https://github.com/terraform-providers/terraform-provider-aws/tree/master/examples/eks-getting-started

- https://learn.hashicorp.com/tutorials/terraform/eks

- https://registry.terraform.io/modules/terraform-aws-modules/eks/aws/2.3.1
