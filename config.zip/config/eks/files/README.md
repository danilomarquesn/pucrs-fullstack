Pasta para criar arquivos.

Exemplos:

- configuração das credenciais
- kubeconfig
- Dockerfile da image: kubectl-aws-cli
