bash kubectl.sh
