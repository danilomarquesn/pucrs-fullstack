docker tag config tonanuvem/config:ubuntu
docker push tonanuvem/config:ubuntu
